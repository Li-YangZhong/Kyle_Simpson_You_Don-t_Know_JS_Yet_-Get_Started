var cmInitContent = 
`// create an array
var a = ['ant', 'bison', 'camel', 'duck', 'elephant'];

// call slice(), passing start and end indexes
var sliced = a.slice(2, 4);

// log the result
console.log(sliced);`;

var cmSelectLine = 4;
var cmSelectChStart = 21;
